sudo apt-get install python-dev libxml2 libxslt1.1 libxslt1-dev libjpeg62-dev
sudo apt-get install python-setuptools
easy_install pip

