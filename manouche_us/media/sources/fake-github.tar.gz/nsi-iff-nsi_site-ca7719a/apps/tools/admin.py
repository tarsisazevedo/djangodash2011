from django.contrib import admin
from apps.tools.models import Tool

admin.site.register(Tool)
