#-*- coding:utf-8 -*-

from django.test import TestCase


class ToolsTest(TestCase):
    pass

