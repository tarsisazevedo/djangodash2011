from django.utils import unittest

from project.models import Project
from project.analyzer import BaseAnalyzer

class BaseAnalyzerTestCase(unittest.TestCase):
    def setUp(self):
        self.project = Project.objects.create(url="media/sources/fake-github.tar.gz")

    def test_base_analyzer_should_receive_a_project_id_and_return_a_list_of_all_python_module_inside_its(self):
        analyzer = BaseAnalyzer(self.project.id)

        python_modules = analyzer.get_project_modules()

        self.assertEquals(python_modules, "")
        analyzer._remove_extracted_code()
